initBootstrapCarousel = function (){
    jQuery('.carousel').carousel();
};
