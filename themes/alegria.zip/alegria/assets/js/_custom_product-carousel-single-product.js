singleProductCarousel = function () {
    jQuery(".product-image-thumbnails a").click(function(event) {
        jQuery("#prod-img").attr("src", jQuery(this).attr("href"));
// prevent href
        event.preventDefault();
        return false;
    });
};

isFirst = function () {
    return jQuery("body.single-fik_product").find(".product-image-thumbnails").children(".thumbnail").first().hasClass("active");
};

isLast = function () {
    return jQuery("body.single-fik_product").find(".product-image-thumbnails").children(".thumbnail").last().hasClass("active");
};



// -------------------- Load Bootstrap carousel
// --------------------

jQuery('.carousel').carousel();


jQuery(function() {
    jQuery(".product-images").swipe( {
        //Generic swipe handler for all directions
        swipeLeft:function(event, direction, distance, duration, fingerCount, fingerData) {
            jQuery( ".arrow-right" ).trigger( "click" );
        },
        swipeRight:function(event, direction, distance, duration, fingerCount, fingerData) {
            jQuery( ".arrow-left" ).trigger( "click" );
        }
    });
});

jQuery(document.documentElement).keyup(function (event) {
  // handle cursor keys
  if (event.keyCode === 37) {
    // go left
    jQuery( ".arrow-left" ).trigger( "click" );
  } else if (event.keyCode === 39) {
    // go right
    jQuery( ".arrow-right" ).trigger( "click" );
  }
});

jQuery(document).ready(function() {
    // LOAD ON THUMBNAIL CLICK -> TO DO
    jQuery(".product-image-thumbnails a").click(function(event) {
        jQuery(this).parents(".product-image-thumbnails").find(".active").removeClass("active");
        jQuery("#prod-img").attr("src", jQuery(this).attr("href"));
        jQuery(this).parent("li").addClass("active");
        event.preventDefault();
        return false;
    });

    // Add active class to first thumbnail
    jQuery("body.single-fik_product").find(".product-image-thumbnails").children(".thumbnail").first().addClass("active");

    // Add arrow only if there is more than one thumbnail
    if ( jQuery("body.single-fik_product").find(".product-image-thumbnails").children(".thumbnail").size() > 1){
        jQuery("body.single-fik_product").find(".arrow-right").css("display","inline-block");
    }

    // Arrows slide
    jQuery(".arrow-right").click(function(event) {
        if (!isLast()){
            // Add active class on next thumbnail
            jQuery(this).parent(".product-image-frame").next(".thumbnails-content").find(".active").next("li").addClass("active");

            // Remove active class for older thumbnail
            jQuery(this).parent(".product-image-frame").next(".thumbnails-content").find(".active").first().removeClass("active");

            // Add left arrow to slider
            jQuery(".arrow-left").css("display","inline-block");

            // Load image on slider
            jQuery("#prod-img").attr("src", jQuery(this).parent(".product-image-frame").next(".thumbnails-content").find(".active").children("a").attr("href"));

            // Delete right arrow on last thumbnail
            if (isLast()){
                jQuery(this).css("display","none");
            } else {
                jQuery(this).css("display","inline-block");
            }
        }
    });

    jQuery(".arrow-left").click(function(event) {
        if (!isFirst()){
            // Add active class on prev thumbnail
            jQuery(this).parent(".product-image-frame").next(".thumbnails-content").find(".active").prev("li").addClass("active");

            // Remove active class for older thumbnail
            jQuery(this).parent(".product-image-frame").next(".thumbnails-content").find(".active").last().removeClass("active");

            // Add right arrow to slider
            jQuery(".arrow-right").css("display","inline-block");

            // Load image on slider
            jQuery("#prod-img").attr("src", jQuery(this).parent(".product-image-frame").next(".thumbnails-content").find(".active").children("a").attr("href"));

            // Delete left arrow on first thumbnail
            if ( isFirst() ){
                jQuery(".arrow-left").css("display","none");
            } else {
                jQuery(".arrow-left").css("display","inline-block");
            }
        }
    });
});
