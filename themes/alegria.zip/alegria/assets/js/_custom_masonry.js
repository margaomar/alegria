blogMasonry = function (){
	cont = document.querySelector('.blog .main');
	gutter = parseInt(jQuery('article').css('marginBottom'));
	msry = new Masonry(cont, {
		columnWidth: 50,
		itemSelector: 'article',
		gutter: gutter
	});
};
