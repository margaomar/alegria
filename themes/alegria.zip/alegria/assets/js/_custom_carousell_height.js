carousellHeight = function(){
$('.carousel').carousel({
    	pause: "false",
    	interval: 4000
	});

	$('.carousel').css({'margin': 0, 'width': $(window).outerWidth(), 'height': $(window).outerHeight()-140});

	$('.carousel-inner').css({'height': '100%'});

	$('.carousel .item').css({ 'width': '100%', 'height': '100%'});

	$('.carousel-inner div.item img').each(function() {
		var imgSrc = $(this).attr('src');

		$(this).parent().append("<div class='fill' style='background: url("+imgSrc+") center center no-repeat; -webkit-background-size: 100%; -moz-background-size:100%; -o-background-size: 100%; background-size:100%; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover; display: block; width:100%; height: 100%;'>&nbsp;</div>");
		$(this).remove();
	});

	$(window).on('resize', function() {
		$('.carousel').css({'width': $(window).outerWidth(), 'height': $(window).outerHeight()-140});
	});
};


$(function() {
  $("#myCarousel").swipe( {
	//Generic swipe handler for all directions
	swipeLeft:function(event, direction, distance, duration, fingerCount, fingerData) {
            jQuery( ".right" ).trigger( "click" );
        },
	swipeRight:function(event, direction, distance, duration, fingerCount, fingerData) {
		jQuery( ".left" ).trigger( "click" );
	}
  });
});

