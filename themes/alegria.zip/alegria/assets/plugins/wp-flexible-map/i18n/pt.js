// Portugese
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["pt"] = {
		"Click for details" : "Clique para detalhes",
		"Directions" : "direções Mapa",
		"From" : "Local de partida",
		"Get directions" : "Obter direcções mapa"
	};

}
