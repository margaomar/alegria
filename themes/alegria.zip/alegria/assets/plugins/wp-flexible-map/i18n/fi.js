// Finnish
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["fi"] = {
		"Click for details" : "Klikkaa lisätietoja",
		"Directions" : "Kartta suuntiin",
		"From" : "Lähtöpaikka",
		"Get directions" : "Hanki kartta ohjeet"
	};

}
