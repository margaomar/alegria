// Greek
// translation by Pantelis Orfanos http://profiles.wordpress.org/ironwiller/ -- thanks!

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["el"] = {
		"Click for details" : "Κάντε κλικ για λεπτομέρειες",
		"Directions" : "Οδηγίες διαδρομής",
		"From" : "Από",
		"Get directions" : "Δείτε διαδρομή"
	};

}
