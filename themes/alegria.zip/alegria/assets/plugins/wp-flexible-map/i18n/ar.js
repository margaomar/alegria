// Arabic
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["ar"] = {
		"Click for details" : "فوق لمزيد من التفاصيل",
		"Directions" : "اتجاهات",
		"From" : "مكان المغادرة",
		"Get directions" : "الحصول على الاتجاهات"
	};

}
