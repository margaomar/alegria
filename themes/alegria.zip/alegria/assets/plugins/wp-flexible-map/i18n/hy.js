// Armenian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["hy"] = {
		"Click for details" : "Նոր մանրամասներ",
		"Directions" : "Քարտեզ ուղղություններն",
		"From" : "Հայը մեկնելը",
		"Get directions" : "ստանալ ուղղությունները"
	};

}
