// Italian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["it"] = {
		"Click for details" : "Clicca per i dettagli",
		"Directions" : "Indicazioni",
		"From" : "Luogo di partenza",
		"Get directions" : "Ottieni indicazioni stradali"
	};

}
