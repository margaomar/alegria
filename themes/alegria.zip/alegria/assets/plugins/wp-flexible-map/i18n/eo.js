// Esperanto
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["eo"] = {
		"Click for details" : "Klaku por detaloj",
		"Directions" : "direktoj",
		"From" : "Loko de partio",
		"Get directions" : "Get direktoj"
	};

}
