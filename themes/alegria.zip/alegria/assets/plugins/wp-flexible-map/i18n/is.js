// Icelandic
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["is"] = {
		"Click for details" : "Smelltu til að fá upplýsingar",
		"Directions" : "leiðbeiningar",
		"From" : "Brottfararstaður",
		"Get directions" : "fá leiðbeiningar"
	};

}
