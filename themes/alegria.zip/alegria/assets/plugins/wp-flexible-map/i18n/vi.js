// Vietnamese
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["vi"] = {
		"Click for details" : "Nhấn vào đây để biết thêm chi tiết",
		"Directions" : "hướng dẫn",
		"From" : "Nơi khởi hành",
		"Get directions" : "nhận được hướng dẫn"
	};

}
