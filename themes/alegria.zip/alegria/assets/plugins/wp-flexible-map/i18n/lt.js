// Lithuanian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["lt"] = {
		"Click for details" : "Click for details",
		"Directions" : "Medis kryptys",
		"From" : "Išvykimo vieta",
		"Get directions" : "Gauti žemėlapio kryptis"
	};

}
