// Russian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["ru"] = {
		"Click for details" : "Нажмите для подробностей",
		"Directions" : "Карта проезда",
		"From" : "Место отправления",
		"Get directions" : "Получить карту направления"
	};

}
