// Thai
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["th"] = {
		"Click for details" : "คลิกที่นี่เพื่อดูรายละเอียด",
		"Directions" : "เส้นทางแผนที่",
		"From" : "สถานที่ออกเดินทาง",
		"Get directions" : "ขอเส้นทางแผนที่"
	};

}
