// Catalan
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["ca"] = {
		"Click for details" : "Feu clic per a més detalls",
		"Directions" : "mapa Direccions",
		"From" : "Lloc de sortida",
		"Get directions" : "Obtenir adreces mapa"
	};

}
