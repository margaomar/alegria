// Tamil
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["ta"] = {
		"Click for details" : "விவரங்களுக்கு சொடுக்கவும்",
		"Directions" : "வரைபடத்தை திசைகளில்",
		"From" : "புறப்படும் இடம்",
		"Get directions" : "திசைகளை பெறவும்"
	};

}
