// Japanese
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["ja"] = {
		"Click for details" : "詳細はこちらをクリック",
		"Directions" : "マップの方向性",
		"From" : "出発地",
		"Get directions" : "地図の方向を得る"
	};

}
