// Serbian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["sr"] = {
		"Click for details" : "Кликните за детаље",
		"Directions" : "Правци",
		"From" : "Место поласка",
		"Get directions" : "Упутства за вожњу"
	};

}
