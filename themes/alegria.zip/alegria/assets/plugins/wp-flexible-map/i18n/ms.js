// Malaysian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["ms"] = {
		"Click for details" : "Klik untuk maklumat lanjut",
		"Directions" : "arahan",
		"From" : "Tempat berlepas",
		"Get directions" : "Dapatkan arah"
	};

}
