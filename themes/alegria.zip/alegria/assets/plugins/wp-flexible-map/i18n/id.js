// Indonesian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["id"] = {
		"Click for details" : "Klik untuk rincian",
		"Directions" : "Arah",
		"From" : "Tempat keberangkatan",
		"Get directions" : "Dapatkan arah"
	};

}
