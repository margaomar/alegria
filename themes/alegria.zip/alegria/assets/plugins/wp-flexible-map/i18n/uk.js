// Ukrainian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["uk"] = {
		"Click for details" : "Натисніть для подробиць",
		"Directions" : "проїзд",
		"From" : "Місце відправлення",
		"Get directions" : "Отримати карту напрямки"
	};

}
