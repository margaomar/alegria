// Hindi
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["hi"] = {
		"Click for details" : "जानकारी के लिए क्लिक करें",
		"Directions" : "नक्शा दिशाओं",
		"From" : "प्रस्थान के प्लेस",
		"Get directions" : "नक्शा दिशाओं"
	};

}
