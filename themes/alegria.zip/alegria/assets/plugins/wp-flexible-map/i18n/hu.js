// Hungarian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["hu"] = {
		"Click for details" : "Kattintson a részletekért",
		"Directions" : "Térkép irányban",
		"From" : "Indulás helye",
		"Get directions" : "Térkép irányban"
	};

}
