// German
// translation by Carib Design http://profiles.wordpress.org/caribdesign/ -- thanks!

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["de"] = {
		"Click for details" : "Für Details klicken",
		"Directions" : "Wegbeschreibung",
		"From" : "Abfahrtsort",
		"Get directions" : "Wegbeschreibung anzeigen"
	};

}
