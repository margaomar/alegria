// Galician
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["gl"] = {
		"Click for details" : "Preme aquí para detalles",
		"Directions" : "direccións Mapa",
		"From" : "Lugar de partida",
		"Get directions" : "obter direccións"
	};

}
