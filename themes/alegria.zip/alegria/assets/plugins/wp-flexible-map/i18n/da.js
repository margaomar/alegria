// Danish
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["da"] = {
		"Click for details" : "Klik for detaljer",
		"Directions" : "Kørselsvejledning",
		"From" : "Afgangssted",
		"Get directions" : "Hent kørselsvejledning"
	};

}
