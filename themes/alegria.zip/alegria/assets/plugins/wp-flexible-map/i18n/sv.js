// Swedish
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["sv"] = {
		"Click for details" : "Klicka för mer information",
		"Directions" : "Karta håll",
		"From" : "Plats för avresa",
		"Get directions" : "Hämta vägbeskrivning"
	};

}
