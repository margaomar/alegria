// Macedonian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["mk"] = {
		"Click for details" : "Кликни за повеќе детали",
		"Directions" : "насоки",
		"From" : "Местото на поаѓање",
		"Get directions" : "добијат насоки"
	};

}
