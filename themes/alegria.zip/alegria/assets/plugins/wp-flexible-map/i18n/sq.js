// Albanian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["sq"] = {
		"Click for details" : "Kliko për detaje",
		"Directions" : "drejtimet",
		"From" : "Vendi i nisjes",
		"Get directions" : "Merr drejtime"
	};

}
