// Korean
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["ko"] = {
		"Click for details" : "자세한 내용을 보려면 클릭하세요",
		"Directions" : "지도 방향",
		"From" : "출발 장소",
		"Get directions" : "지도 길찾기"
	};

}
