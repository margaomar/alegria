// Farsi/Persian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["fa"] = {
		"Click for details" : "برای جزئیات کلیک کنید",
		"Directions" : "جهت نقشه",
		"From" : "محل عزیمت",
		"Get directions" : "جهت نقشه"
	};

}
