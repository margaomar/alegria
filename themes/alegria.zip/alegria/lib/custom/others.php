<?php

/*
*   Add support for upload SVG
*/

function cc_mime_types( $mimes ){
	$mimes['svg'] = 'image/svg+xml';
	return $mimes;
}
add_filter( 'upload_mimes', 'cc_mime_types' );

/*
*   Add shortcode support on text widgets
*/

add_filter('widget_text', 'do_shortcode');

/*
*   Add wpautop
*/

add_filter( 'the_content', 'wpautop', 10 );

/* 
 * This functions allows to get the contents of a template into a variable,
 * needed for shortcodes. 
 */

if ( !function_exists( 'load_template_part' ) ){
	function load_template_part($template_name, $part_name=null) {
	    ob_start();
	    get_template_part($template_name, $part_name);
	    $var = ob_get_contents();
	    ob_end_clean();
	    return $var;
	}
}

/*
 * This functions allows to detect is some page is blog
 */

function is_blog () {
	global  $post;
	$posttype = get_post_type($post );
	return ( ((is_archive()) || (is_author()) || (is_category()) || (is_home()) || (is_single()) || (is_tag())) && ( $posttype == 'post')  ) ? true : false ;
}

/*
 * This function get the subcategory product name
 */
function get_the_subcateg_name($id) {
	//$subcateg_term = get_term_by('name', 'Sombreros', 'store-section');
	$terms = wp_get_post_terms($id, 'store-section');

	// un array con las subsecciones de la tienda que queremos mostrar en productos
	if (WP_ENV == "dev"){
		$subcategorias_tienda = array(6,8,9,10);
	}else{
		$subcategorias_tienda = array(7,8,9,10);
	}
	foreach($terms as $childcat) {
		if (in_array($childcat->parent, $subcategorias_tienda)){
			return $childcat->name;
		}
	}
}



// Apply filter--> putting the slug of the product as class on body classes
add_filter('body_class', 'alegria_body_classes');

function alegria_body_classes($classes) {
		global $post;
        $slug = strtolower(str_replace(' ', '-', trim($post->post_name)));
        $classes[] = $slug;
        return $classes;
}
