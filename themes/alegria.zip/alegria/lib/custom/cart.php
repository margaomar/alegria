<?php

/*
*   Customize cart table
*/

add_filter('cart_format', 'customize_cart');

function customize_cart($format){

    $format['before_cart'] = '<table class="table">';
    $format['after_cart'] = '</table>';
    $format['before_header_row'] = '<tr>';
    $format['after_header_row'] = '</tr>';
    $format['before_row'] = '<tr id="cart_item_%s" class="cart_item_row">';
    $format['after_row'] = '</tr>';
    $format['before_element'] = '<td>';
    $format['after_element'] = '</td>';
    $format['before_header'] = '<thead>';
    $format['after_header'] = '</thead>';
    $format['before_header_element'] = '<th>';
    $format['after_header_element'] = '</th>';
    $format['before_body'] = '<tbody>';
    $format['after_body'] = '</tbody>';
    $format['before_total'] = '<tfoot><tr class="fik-cart-subtotal-row">';
    $format['after_total'] = '</tr></tfoot>';
    $format['before_total_title'] = '<td colspan="4" class="text-left"><strong>';
    $format['after_total_title'] = '</strong></td>';
    $format['before_total_element'] = '<td><strong>';
    $format['after_total_element'] = '</strong></td>';
    $format['cart_image_element'] = '<td class="cart_image"><a href="%s"><img src="%s" alt="%s"></a></td>';
    $format['product_name_element'] = '<td><a href="%s">%s</a><br/>%s</td>';
    $format['product_price'] = '<td>%s</td>';
	$format['quantity_form'] = '<td><form action="" method="post"><input type="hidden" name="cart_item_%s" value="%s" class="nueva_clase"><input type="number" name="cart_item_%s_quantity" min="0" max="10" step="1" value="%s" placeholder="%s" class="input-mini" required=""><button type="submit" class="cart_item_update btn btn-small btn-primary" name="update_quantity">%s</button></form></td>';
    $format['product_subtotal'] = '<td>%s</td>';
    $format['checkout_form'] = '<form action="" class="fik_to_checkout text-right" method="post" enctype="multipart/form-data"><button name="checkout" type="submit" class="button alt btn btn-large btn-primary">%s</button></form>';
	$format['before_header_remove_item'] = '<th>';
    $format['after_header_remove_item'] = '</th>';
    $format['before_total_remove_item'] = '<td>';
    $format['after_total_remove_item'] = '</td>';
    $format['before_total_element'] = '<td style="text-align: right">';
    $format['remove_item_form'] = '<td><form action="" method="post"><input type="hidden" name="cart_item_%s" value="%s">
        <input type="number" name="cart_item_%s_quantity" value="0" class="input-mini hide" required="">
        <button type="submit" class="cart_item_update_ btn btn-small" name="update_quantity" style="background-color: transparent"><span class="remove-item">✕</span></button></form></td>';

    return $format;
}
