<?php setup_postdata($post); ?>

    <article itemscope itemtype="http://schema.org/Product" id="product-<?php the_ID(); ?>" <?php post_class(); ?>>

        <div class="row">
            <form action="" class="fik_add_cart" method="post" enctype="multipart/form-data">
            <input type="hidden" name="store_product_id" value="' . esc_attr(the_ID()) . '" />
				<?php if(has_post_thumbnail()) : ?>
				<div class="product-images col-xs-12 col-sm-12 col-md-7 col-md-pull-1 col-lg-6 col-lg-pull-3 pull-right">
					<div class="product-image-frame">
						<?php
							// We print the product thumbnail
							the_post_thumbnail('store-single-product-custom-thumbnail',array('id' => 'prod-img', 'class' => 'img-thumbnail'));
						?>
						<span class="arrow arrow-left"><span class="arrow-container">&larr;</span></span>
                    	<span class="arrow arrow-right"><span class="arrow-container">&rarr;</span></span>
					</div>

					<div class="thumbnails-content">
						<?php
							// this function outputs a <ul> with class="product-image-thumbnails" where each <li> is a thumbnil that links to a biger image (sizes specified in function).
							// We also pass the size of the zoom image which url and size are returned as data attributes of the img. The last 2 sizes are the max width of the video thumbnail and the max width of a video embed
							the_product_gallery_thumbnails(array(150,150) , 'store-single-product-custom-thumbnail', 'store-single-product-custom-thumbnail-zoom');
						 ?>
					 </div>
					<?php echo get_add_to_cart_button(); ?>
					<div class="row hidden-md hidden-lg hidden-sm cont_title">
						<div class="col-xs-12">
							<h1 itemprop="name" class="title"><?php the_title(); ?></h1>
						</div>
						<div class="product-price col-xs-12">
								<?php the_fik_previous_price(); ?>
								<?php the_fik_price(); ?>
						</div>
					</div>
				</div>
				<?php endif; ?>

				<div class="product-info col-sm-10 col-sm-offset-1 col-md-4 col-md-offset-0 col-lg-3">
					<div class="row">
						<header class="col-xs-12">
							<h1 itemprop="name" class="product-title"><?php the_title(); ?></h1>
							<p class="prod-subcat"><?php echo get_the_subcateg_name($post->ID) ?></p>
						</header>
						<div class="product-price col-xs-12 hidden-xs">
							<?php the_fik_previous_price(); ?>
							<?php the_fik_price(); ?>
						</div>
						<div class="product-options col-xs-12">
							<?php echo get_fik_product_select_variations(null, true); ?>
							<?php echo '<span class="hidden">' . get_fik_product_select_quantity() . '</span>'; ?>
							<?php echo get_add_to_cart_button(); ?>
						</div>
						<div class="product-description col-xs-12">
							<?php the_content(); ?>
						</div>
						<?php if ( is_active_sidebar( 'widget-area-product-description-bottom' ) ) : ?>
						  <footer class="widget-area-product-description-bottom col-xs-12">
							<?php dynamic_sidebar('widget-area-product-description-bottom'); ?>
						  </footer>
						<?php endif; ?>
					</div>
				</div>
			</form>
            <?php if ( is_active_sidebar( 'widget-area-product-bottom' ) ) : ?>
                <footer class="widget-area-product-bottom col-xs-12">
                <?php dynamic_sidebar('widget-area-product-bottom'); ?>
                </footer>
            <?php endif; ?>
        </div>
        <?php comments_template('/templates/comments.php'); ?>
    </article>
