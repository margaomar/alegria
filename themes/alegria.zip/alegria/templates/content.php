
<?php
$text_align_a = get_post_custom_values('text_align');
if ($text_align_a[0]){
	$text_align = $text_align_a[0];
}else{
	$text_align = 'bottom';
}

$image_cols_a = get_post_custom_values('image_cols');
if ($image_cols_a[0]){
	$image_cols = $image_cols_a[0];
}else{
	$image_cols = 'col-sm-8';
}

$image_offset_a = get_post_custom_values('image_offset');
if ($image_offset_a[0]){
	$image_offset = $image_offset_a[0];
}

if (isset($image_offset)){
	$text_offset = substr($image_offset, -1);
	$text_offset = 'col-sm-offset-' . ($text_offset + 3);
}else{
	$text_offset = 'col-sm-offset-3';
}

?>

<article <?php post_class('col-sm-4'); ?>>
	<?php if ( has_post_thumbnail() ) { ?>
		<div class="row">
			<figure class="featured-image <?php echo $image_cols . ' ' . $image_offset ?>">
				<?php the_post_thumbnail( 'post-custom-thumbnail', array('class' => 'img-responsive') ); ?>
			</figure>
			<?php } ?>
			<div class="entry-summary <?php echo $text_align; ?> col-sm-6 <?php echo $text_offset; ?>">
				<?php the_excerpt(); ?>
			</div>
		</div>
</article>
