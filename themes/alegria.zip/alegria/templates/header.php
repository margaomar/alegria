<header class="banner navbar navbar-fixed-top navbar-default" role="banner">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed dl-trigger">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>/">
          <?php the_store_logo(null, array('class' => 'logo')); ?>
      </a>
      <?php if(get_bloginfo('description') !=''){ ?>
        <div class="navbar-brand-description"><?php echo get_bloginfo('description'); ?></div>
      <?php } ?>
    </div>

    <nav class="pull-right cart-container">
      <?php
        if (has_nav_menu('cart_menu')) :
          wp_nav_menu(array('theme_location' => 'cart_menu', 'menu_class' => 'nav navbar-nav cart-menu'));
        endif;
        ?>
    </nav>

    <nav id="dl-menu" class="dl-menuwrapper" role="navigation">

      <?php
        if (has_nav_menu('primary_navigation')) :
          wp_nav_menu(array('theme_location' => 'primary_navigation', 'menu_class' => 'nav navbar-nav', 'menu_class' => 'dl-menu', 'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>', 'walker' => new Mobile_Nav_Walker()));
        endif;
      ?>
    </nav>

  </div>
</header>
