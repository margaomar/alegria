<footer class="content-info" role="contentinfo">
  <div class="container">
    <div class="row">
      <section class="col-sm-6 col-md-15">
         <?php if (has_nav_menu('footer_col1')) {
					wp_nav_menu(array(
						'theme_location' => 'footer_col1',
						'menu_class' => 'footer_nav',
					));
                 } ?>
      </section>
      <section class="col-sm-6 col-md-15">
        <?php if (has_nav_menu('footer_col2')) {
                    wp_nav_menu(array(
                        'theme_location' => 'footer_col2',
                        'menu_class' => 'footer_nav',
                    ));
				} ?>
      </section>
      <div class="clearfix visible-sm-block"></div>

      <section class="col-sm-6 col-md-15">
        <?php dynamic_sidebar('widget-area-footer-three'); ?>
      </section>
      <section class="col-sm-6 col-md-15">
        <?php dynamic_sidebar('widget-area-footer-four'); ?>
      </section>
      <section class="col-sm-6 col-md-15">
			<ul class="footer_nav no_hover copy">

				<li>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?> </li>
				<li> <?php the_fikstores_badge(); ?></li>
		  	</ul>
	  </section>
    </div>

  </div>
</footer>

<?php wp_footer(); ?>
