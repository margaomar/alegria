<?php get_template_part('templates/content', 'fik_product-single'); ?>
