<?php
/**
 * Custom functions
 */

require_once locate_template('/lib/custom/shortcodes/shortcodes.php');
require_once locate_template('/lib/custom/widgets.php');
require_once locate_template('/lib/custom/menus.php');
require_once locate_template('/lib/custom/cart.php');
require_once locate_template('/lib/custom/bootstrap_clearfix.php');
require_once locate_template('/lib/custom/others.php');
require_once locate_template('/lib/custom/plugins.php');

// Bug testing only. Not to be used on a production site
// require_once locate_template('/lib/custom/debug.php');
