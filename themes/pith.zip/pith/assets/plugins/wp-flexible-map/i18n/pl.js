// Polish
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["pl"] = {
		"Click for details" : "Kliknij po szczegóły",
		"Directions" : "Dojazd",
		"From" : "Miejsce wyjazdu",
		"Get directions" : "Pobierz Dojazd"
	};

}
