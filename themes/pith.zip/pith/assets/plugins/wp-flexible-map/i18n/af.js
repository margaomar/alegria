// Afrikaans
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["af"] = {
		"Click for details" : "Klik vir meer inligting",
		"Directions" : "padkaart",
		"From" : "Plek van vertrek",
		"Get directions" : "Kry padkaart"
	};

}
