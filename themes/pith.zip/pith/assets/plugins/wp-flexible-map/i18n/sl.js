// Slovenian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["sl"] = {
		"Click for details" : "Klikni za podrobnosti",
		"Directions" : "Navodila",
		"From" : "Kraj odhoda",
		"Get directions" : "Navodila za pot"
	};

}
