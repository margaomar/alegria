// Turkish
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["tr"] = {
		"Click for details" : "Detaylar için tıklayın",
		"Directions" : "harita tarifi",
		"From" : "Kalkış Yeri",
		"Get directions" : "Harita tarifi alın"
	};

}
