// Dutch
// translation by Ivan Beemster http://www.lijndiensten.com/ -- thanks!

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["nl"] = {
		"Click for details" : "Klik hier voor details",
		"Directions" : "Routebeschrijving",
		"From" : "Plaats van vertrek",
		"Get directions" : "Routebeschrijving opvragen"
	};

}
