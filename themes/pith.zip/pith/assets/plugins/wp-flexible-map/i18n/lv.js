// Latvian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["lv"] = {
		"Click for details" : "Noklikšķiniet uz detaļām",
		"Directions" : "virzieni",
		"From" : "Atiešanas vieta",
		"Get directions" : "Saņemt kartes virzienus"
	};

}
