// Norwegian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["nb"] = {
		"Click for details" : "Klikk for detaljer",
		"Directions" : "kartanvisninger",
		"From" : "Avgangssted",
		"Get directions" : "Få kartanvisninger"
	};

}
