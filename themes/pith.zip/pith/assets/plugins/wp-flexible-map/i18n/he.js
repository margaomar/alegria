// Hebrew
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["he"] = {
		"Click for details" : "לחץ לפרטים נוספים",
		"Directions" : "כיוונים",
		"From" : "מקום יציאה",
		"Get directions" : "קבל הוראות"
	};

}
