// Spanish
// translation by edurramos http://wordpress.org/support/profile/edurramos -- thanks!

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["es"] = {
		"Click for details" : "Haga clic para más detalles",
		"Directions" : "Cómo llegar",
		"From" : "Desde",
		"Get directions" : "Obtener ruta"
	};

}
