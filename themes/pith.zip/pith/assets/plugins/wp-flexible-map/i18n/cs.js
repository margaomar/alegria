// Czech
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["cs"] = {
		"Click for details" : "Klikněte pro detail",
		"Directions" : "Mapa směry",
		"From" : "Místo odletu",
		"Get directions" : "Získat mapu trasy"
	};

}
