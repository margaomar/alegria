// Croatian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["hr"] = {
		"Click for details" : "Kliknite za detalje",
		"Directions" : "Smjerovi",
		"From" : "Mjesto polaska",
		"Get directions" : "Nabavite karte smjerove"
	};

}
