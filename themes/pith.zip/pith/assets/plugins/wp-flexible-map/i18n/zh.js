// Chinese
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["zh"] = {
		"Click for details" : "點擊查看詳情",
		"Directions" : "方向",
		"From" : "出發地點",
		"Get directions" : "獲取路線"
	};

}
