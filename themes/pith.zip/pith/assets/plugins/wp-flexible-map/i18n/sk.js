// Slovak
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["sk"] = {
		"Click for details" : "Kliknite pre detail",
		"Directions" : "Mapa smermi",
		"From" : "Miesto odletu",
		"Get directions" : "Získať mapu trasy"
	};

}
