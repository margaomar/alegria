// Azerbaijani
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["az"] = {
		"Click for details" : "Detaylar üçün tıklayınız",
		"Directions" : "istiqamətləri",
		"From" : "Gediş yeri",
		"Get directions" : "istiqamətləri almaq"
	};

}
