// Bosnian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["bs"] = {
		"Click for details" : "Кликнете за повече информация",
		"Directions" : "Карта на посоки",
		"From" : "Място на тръгване",
		"Get directions" : "Получаване на карта посоки"
	};

}
