// Romanian
// from Google Translate -- please help improve this translation

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["ro"] = {
		"Click for details" : "Click pentru detalii",
		"Directions" : "direcţii",
		"From" : "Locul de plecare",
		"Get directions" : "Obţineţi indicaţii"
	};

}
