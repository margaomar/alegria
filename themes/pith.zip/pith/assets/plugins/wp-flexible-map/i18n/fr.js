// French
// from Google Translate -- please help improve this translation

// feedback from user:
// "space":"space", colon can't be close to text (ref http://goo.gl/A2DgH)

if (typeof FlexibleMap != "undefined") {

	FlexibleMap.prototype.i18n["fr"] = {
		"Click for details" : "Cliquez pour plus de détails",
		"Directions" : "Itinéraire",
		"From" : "Lieu de départ ",
		"Get directions" : "Itinéraire"
	};

}
